import React from 'react';
import ReactDOM from 'react-dom';
import AIContentGenerator from './App';

ReactDOM.render(<AIContentGenerator />, document.getElementById('root'));